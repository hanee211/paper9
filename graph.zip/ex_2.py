class Model():
	def __init__(self):
		self.a = 123
		
		self.b = "hello"
		c = 100
		a = 100
		
		self.d = c + self.a