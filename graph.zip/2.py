class Model():
	def __init__(self):
		self.a = 123
		
		self.b = "hello"